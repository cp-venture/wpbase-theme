<?php
/* add_ons_php */
?>
		<ul class="tabs-menu fl-wrap no-list-style">
            <li class="current"><a href="#filters-search"><?php _e( '<i class="fal fa-sliders-h"></i> Filters', 'townhub-add-ons' ); ?></a></li>
            <li><a href="#category-search"><?php _e( '<i class="fal fa-image"></i>Categories', 'townhub-add-ons' ); ?></a></li>
        </ul>