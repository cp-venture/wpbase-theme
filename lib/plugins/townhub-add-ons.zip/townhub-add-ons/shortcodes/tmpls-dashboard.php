<?php
/* add_ons_php */

?>
<script type="text/template" id="tmpl-user-social">
    <?php townhub_addons_get_template_part('templates-inner/social');?>
</script>
